# -*- coding: utf-8 -*-
"""
@author: Jennifer Gilroy
@name: 4-1 Milestone: Create & Read in Python
@course: CS-340-H6993
"""

from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    # CRUD operations for Animal collection in MongoDB
    

    def __init__(self, username, password, port):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:%s/?authMechanism=DEFAULT&authSource=AAC' % (username, password, port))
        self.database = self.client['AAC']
         
            
    # Helper Function ~ Counts the number of documents
    def count_docs(self, data):
        if data is not None:
            document_count = self.database.animals.count_documents(data)
            return document_count
        else:
            raise Exception('Nothing to count because data parameter is empty')

            
    # Function to Insert a document ~ C in CRUD
    def create(self, data):
        if data is not None:
            # Will return the generated _id object
            animal_id = self.database.animals.insert(data)  # data should be dictionary
            # Insert successful (_id generated so document inserted)
            if animal_id is not None:
                return True
            
            else:
                return False
            
        else:
            raise Exception('Nothing to save because data parameter is empty')
 

    # Function to Query documents ~ R in CRUD
    def read(self, query_data):
        if query_data is not None:
            result = self.database.animals.find(query_data, {'_id': False})
            
        else:
            result = self.database.animals.find({}, {'_id': False})
            
        # Returns a cursor object
        return result
 

    # Function to Update documents ~ U in CRUD
    def update(self, query_data, new_data):
        if query_data is not None and new_data is not None:
            # Count the number of documents with the original information
            count_to_update = self.database.animals.count_documents(query_data)
            # Count the number of documents that currently match the new information
            count_new_data = self.database.animals.count_documents(new_data)
            
            # Evaluate if there are any documents to update
            if count_to_update != 0:
                # Count the number of documents that currently match the new information
                count_current_match = self.database.animals.count_documents(new_data)
                
                updated_animal = self.database.animals.update_many(query_data, {'$set': new_data})
            
                # Count the number of documents with the new information again
                count_new_data = self.database.animals.count_documents(new_data)
                # Calculate how may documents were updated
                count_updated = count_new_data - count_current_match
            
                # Verify the number of documents updated = the number to update
                if count_updated == count_to_update:
                    return updated_animal.raw_result
                
                else:
                    print('There was a problem! - ', count_to_update, ' should have been updated but actual count was ', count_new_data)
                    
            else:
                print('Nothing to update because no documents match data parameter')
                
        else:
            raise Exception('Nothing to update because one or more data parameters are empty')
 

     # Function to Delete document(s) ~ D in CRUD       
    def delete(self, delete_data):
        if delete_data is not None:
            # Count the number of docments to delete
            count_to_delete = self.database.animals.count_documents(delete_data)
            
            if count_to_delete != 0:
                # Count the total number of documents
                count_original = self.database.animals.count_documents({})
            
                result = self.database.animals.delete_many(delete_data)
            
                # Count the number of documents again
                count_new = self.database.animals.count_documents({})
                # Calulate how many documents were deleted
                count_deleted = count_original - count_new
            
                # Verify the number of documents deleted = the number to delete
                if count_deleted == count_to_delete:
                    return result.raw_result
                
                else:
                    print('There was a problem! - ', count_to_delete, ' should have been removed but actual count was ', count_deleted)
                    
            else:
                print('Nothing to delete because no documents match data paramater')
                
        else:
            raise Exception('Nothing to delete because data parameter is empty')

            
        
   
